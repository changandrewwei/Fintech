#!/bin/bash

set -e

pydoc "portfolioopt.portfolioopt" >"portfolioopt.txt"
echo "Documentation generated."

